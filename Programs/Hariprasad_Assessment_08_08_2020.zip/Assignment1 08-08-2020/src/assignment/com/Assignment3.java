package assignment.com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) 
	{
		List<Integer> list = new ArrayList<Integer>();
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		for(int i=0;i<n;i++)
		{
			list.add(s.nextInt());
		}
		int q =s.nextInt();
		for(int i=0;i<q;i++)
		{
			int a,b;
			String str = s.next();
			if(str.equalsIgnoreCase("Insert"))
			{
				a=s.nextInt();
				b=s.nextInt();
				list.add(a, b);
			}
			else if(str.equalsIgnoreCase("Delete"))
			{
				a=s.nextInt();
				list.remove(a);
			}
		}
		Iterator<Integer> i =list.iterator();
		while(i.hasNext())
		{
			System.out.print(i.next()+" ");
		}
	}

}
