package hospital1.com;

public class UnAuthorizedAccessException extends Exception {
	
	public UnAuthorizedAccessException(String s) {
	}

}
