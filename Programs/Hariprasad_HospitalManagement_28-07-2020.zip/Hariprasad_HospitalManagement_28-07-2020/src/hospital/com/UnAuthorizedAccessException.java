package hospital.com;

public class UnAuthorizedAccessException extends Exception {
	
	public UnAuthorizedAccessException(String s) {
	}

}
